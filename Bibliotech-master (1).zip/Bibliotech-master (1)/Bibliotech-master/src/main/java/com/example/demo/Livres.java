package com.example.demo;

import java.util.Date;

public class Livres {
    private String titre;
    private String auteur;
    private String presentation;
    private Date parution;
    private int col;
    private int rank;

    public Livres(String titre, String auteur, String presentation, int col, int rank) {
        this.titre = titre;
        this.auteur = auteur;
        this.presentation = presentation;
      //  this.parution = parution;
        this.col = col;
        this.rank = rank;
    }

    public void setTitre(String titre){
        this.titre = titre;
    }

    public String getTitre() {
        return titre;
    }

    public String getAuteur() {
        return auteur;
    }

    public void setAuteur(String auteur) {
        this.auteur = auteur;
    }

    public String getPresentation() {
        return presentation;
    }

    public void setPresentation(String presentation) {
        this.presentation = presentation;
    }

    public Date getParution() {
        return parution;
    }

    public void setParution(Date parution) {
        this.parution = parution;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }
}
