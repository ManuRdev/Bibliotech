package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.ResourceBundle;

import static java.lang.Integer.parseInt;

public class HelloController implements Initializable {

    @FXML
    private TableView<Livres> TableViewlivre;

    @FXML
    private TableColumn<Livres, String> Titrecol;

    @FXML
    private TableColumn<Livres, String> Auteurcol;

    @FXML
    private TableColumn<Livres, String> Presentationcol;

    @FXML
    private TableColumn<Livres, Date> Parutioncol;

    @FXML
    private TableColumn<Livres, Integer> Colon;

    @FXML
    private TableColumn<Livres, Integer> Rangecol;

    @FXML
    private TextField titre;

    @FXML
    private TextField aut;

    @FXML
    private TextField pres;

    @FXML
    private TextField par;

    @FXML
    private TextField rang;

    @FXML
    private TextField col;

    @FXML
    private Button valider;

    @FXML
    void message(ActionEvent event) {
        System.out.println(rang.getText());
        Livres livres = new Livres (titre.getText(),
                aut.getText(),
                pres.getText(),
             //  Date.from(Instant.parse(par.getText())),
                parseInt(rang.getText()),
                parseInt(col.getText()));
    TableViewlivre.getItems().add(livres);

    }

    @FXML
    void supp (ActionEvent event) {
        int selectedID = TableViewlivre.getSelectionModel().getSelectedIndex();
        TableViewlivre.getItems().remove(selectedID);
    }
    @Override
    public void initialize(URL url, ResourceBundle ResourceBundle ) {

        Titrecol.setCellValueFactory(new PropertyValueFactory<Livres, String> ("titre"));
        Auteurcol.setCellValueFactory(new PropertyValueFactory<Livres, String> ("auteur"));
        Presentationcol.setCellValueFactory(new PropertyValueFactory<Livres, String> ("presentation"));
       // Parutioncol.setCellValueFactory(new PropertyValueFactory<Livres, Date> ("parution"));
        Colon.setCellValueFactory(new PropertyValueFactory<Livres, Integer>("col"));
        Rangecol.setCellValueFactory(new PropertyValueFactory<Livres, Integer>("rank"));

    }
}
